public class BinarySearchTreeNode{
    private BinarySearchTreeNode linkesKind; 
    private BinarySearchTreeNode rechtesKind;
    private Double wert;

    BinarySearchTreeNode(){}
    public void add(final Double wert) {
            if (this.wert ==null){
                this.wert = wert;
            }
            else if (wert<this.wert){
                    if (linkesKind==null){ 
                        linkesKind = new BinarySearchTreeNode(); 
                    }
                    linkesKind.add(wert);}
            else if (wert>this.wert){
                    if (rechtesKind==null){
                        rechtesKind = new BinarySearchTreeNode();
                    }
                    rechtesKind.add(wert);
                }
            }
    public int getHeight(){
        if (linkesKind == null&& rechtesKind == null){
            return 1;
        }
        else{
            if (linkesKind==null){
                return rechtesKind.getHeight()+1;
            }
            else if (rechtesKind==null){
                return linkesKind.getHeight()+1;
            }
            else if(linkesKind.getHeight()<rechtesKind.getHeight()){ 
                return rechtesKind.getHeight()+1;
            }
            else{
                    return linkesKind.getHeight()+1;
                }
            }
        }
}