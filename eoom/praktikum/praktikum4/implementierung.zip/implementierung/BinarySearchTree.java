public class BinarySearchTree {
    public BinarySearchTreeNode root;


    public BinarySearchTree(){}

    public void add(final Double number){
        if (root==null){root=new BinarySearchTreeNode();}
        root.add(number); 
    }
    public int getHeight(){
        return root.getHeight();
    }
}
