public class GeometrischesObjektException extends Exception{
    GeometrischesObjektException(){}
    GeometrischesObjektException(String message){
        super("Geometrisches Objekt: "+message);
    }
}
