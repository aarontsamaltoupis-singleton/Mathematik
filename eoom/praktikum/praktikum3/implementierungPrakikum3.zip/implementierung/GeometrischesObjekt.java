public interface GeometrischesObjekt {
    public double getVolumen();
    public double getOberflaeche();
}
